from functools import wraps






@munch(1, 4)
def fib():
    return 'Fibonacci'

print(fib())