





def printfib():
    '''return Fibonacci'''
    return 'Fibonacci'