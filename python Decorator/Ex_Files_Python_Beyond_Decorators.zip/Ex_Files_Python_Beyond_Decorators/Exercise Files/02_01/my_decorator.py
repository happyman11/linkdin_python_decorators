




def pfib():
    '''Print out Fibonacci'''
    return 'Fibonacci'
